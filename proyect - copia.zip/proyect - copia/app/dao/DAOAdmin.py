import mysql.connector

class DAOAdmin:
    def connect(self):
        config = {
        'user': 'root',
        'password': 'root',
        'host': 'db',
        'port': '3306',
        'database': 'proyecto'
        }
        return mysql.connector.connect(**config)

    def read(self, id):
        con = DAOAdmin.connect(self)
        cursor = con.cursor()

        try:
            if id == None:
                cursor.execute('SELECT * FROM administradores order by empresa desc')
            else:
                cursor.execute("SELECT * FROM administradores where id = %s order by empresa desc", (id,))
            return cursor.fetchall()
        except:
            return ()
        finally:
            con.close()

    def insert(self,data):
        con = DAOAdmin.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("INSERT INTO administradores(empresa,usuario,contrasena) VALUES(%s, %s, %s)", (data['empresa'],data['usuario'],data['contrasena'],))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def update(self, id, data):
        con = DAOAdmin.connect(self)
        cursor = con.cursor()

        try:
            print(data)
            cursor.execute("UPDATE administradores set empresa = %s, usuario = %s, contrasena = %s where id = %s", (data['empresa'], data['usuario'], data['contrasena'], id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def delete(self, id):
        con = DAOAdmin.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("DELETE FROM administradores where id = %s", (id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()


    def validar(self, usuario, contrasena):
        con = DAOAdmin.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("SELECT COUNT(*) FROM administradores WHERE usuario = %s AND contrasena = %s", (usuario, contrasena,))
            count = cursor.fetchone()[0]
            return count > 0
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def get_empresa(self, usuario, contrasena):
        con = DAOAdmin.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("SELECT empresa FROM administradores WHERE usuario = %s AND contrasena = %s", (usuario, contrasena,))
            empresa = cursor.fetchone()
            return empresa[0] if empresa else None
        except Exception as e:
            con.rollback()
            return False
        finally:
            con.close()