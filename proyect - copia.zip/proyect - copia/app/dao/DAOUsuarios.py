import mysql.connector

class DAOUsuarios:
    def connect(self):
        config = {
        'user': 'root',
        'password': 'root',
        'host': 'db',
        'port': '3306',
        'database': 'proyecto'
        }
        return mysql.connector.connect(**config)

    def read(self, id):
        con = DAOUsuarios.connect(self)
        cursor = con.cursor()

        try:
            if id == None:
                cursor.execute('SELECT * FROM usuarios order by empresa desc')
            else:
                cursor.execute("SELECT * FROM usuarios where id = %s order by empresa desc", (id,))
            return cursor.fetchall()
        except:
            return ()
        finally:
            con.close()

    def insert(self,data):
        con = DAOUsuarios.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("INSERT INTO usuarios(empresa,usuario,contrasena) VALUES(%s, %s, %s)", (data['empresa'],data['usuario'],data['contrasena'],))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def update(self, id, data):
        con = DAOUsuarios.connect(self)
        cursor = con.cursor()

        try:
            print(data)
            cursor.execute("UPDATE usuarios set empresa = %s, usuario = %s, contrasena = %s where id = %s", (data['empresa'], data['usuario'], data['contrasena'], id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def delete(self, id):
        con = DAOUsuarios.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("DELETE FROM usuarios where id = %s", (id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def validar(self, usuario, contrasena):
        con = DAOUsuarios.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("SELECT COUNT(*) FROM usuarios WHERE usuario = %s AND contrasena = %s", (usuario, contrasena,))
            count = cursor.fetchone()[0]
            return count > 0
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def get_empresa(self, usuario, contrasena):
        con = DAOUsuarios.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("SELECT empresa FROM usuarios WHERE usuario = %s AND contrasena = %s", (usuario, contrasena,))
            empresa = cursor.fetchone()[0]
            return empresa
        except Exception as e:
            con.rollback()
            return False
        finally:
            con.close()