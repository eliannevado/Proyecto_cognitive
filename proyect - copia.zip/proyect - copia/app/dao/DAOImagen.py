import mysql.connector

class DAOImagen:
    def connect(self):
        config = {
        'user': 'root',
        'password': 'root',
        'host': 'db',
        'port': '3306',
        'database': 'proyecto'
        }
        return mysql.connector.connect(**config)

    def read(self, id):
        con = DAOImagen.connect(self)
        cursor = con.cursor()

        try:
            if id == None:
                cursor.execute('SELECT * FROM imagen order by fecha_hora desc')
            else:
                cursor.execute("SELECT * FROM imagen where id = %s order by fecha_hora desc", (id,))
            return cursor.fetchall()
        except:
            return ()
        finally:
            con.close()

    def insert(self,data):
        con = DAOImagen.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("INSERT INTO imagen(empresa,fecha_hora,imagen) VALUES(%s, NOW(), %s)", (data['empresa'],data['imagen'],))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def update(self, id, data):
        con = DAOImagen.connect(self)
        cursor = con.cursor()

        try:
            print(data)
            cursor.execute("UPDATE imagen set empresa = %s, imagen = %s where id = %s", (data['empresa'], data['imagen'], id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def delete(self, id):
        con = DAOImagen.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("DELETE FROM imagen where id = %s", (id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()
