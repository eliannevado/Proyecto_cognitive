import mysql.connector

class DAOTemperatura:
    def connect(self):
        config = {
        'user': 'root',
        'password': 'root',
        'host': 'db',
        'port': '3306',
        'database': 'proyecto'
        }
        return mysql.connector.connect(**config)

    def read(self, id):
        con = DAOTemperatura.connect(self)
        cursor = con.cursor()

        try:
            if id == None:
                cursor.execute('SELECT * FROM temperatura order by fecha_hora desc')
            else:
                cursor.execute("SELECT * FROM temperatura where id = %s order by fecha_hora desc", (id,))
            return cursor.fetchall()
        except:
            return ()
        finally:
            con.close()

    def read_empresa(self, empresa):
        con = DAOTemperatura.connect(self)
        cursor = con.cursor()

        try:
            if empresa is None:
                cursor.execute('SELECT * FROM temperatura ORDER BY fecha_hora DESC')
            else:
                cursor.execute("SELECT * FROM temperatura WHERE empresa = %s ORDER BY fecha_hora DESC", (empresa,))
            return cursor.fetchall()
        except:
            return ()
        finally:
            con.close()

    def insert(self,data):
        con = DAOTemperatura.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("INSERT INTO temperatura(empresa,fecha_hora,temperatura) VALUES(%s, NOW(), %s)", (data['empresa'],data['temperatura'],))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def update(self, id, data):
        con = DAOTemperatura.connect(self)
        cursor = con.cursor()

        try:
            print(data)
            cursor.execute("UPDATE temperatura set empresa = %s, temperatura = %s where id = %s", (data['empresa'], data['temperatura'], id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()

    def delete(self, id):
        con = DAOTemperatura.connect(self)
        cursor = con.cursor()

        try:
            cursor.execute("DELETE FROM temperatura where id = %s", (id,))
            con.commit()
            return True
        except:
            con.rollback()
            return False
        finally:
            con.close()
