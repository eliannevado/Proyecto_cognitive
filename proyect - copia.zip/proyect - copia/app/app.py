from flask import Flask, render_template, flash, redirect, url_for, request, session, jsonify
from flask_socketio import SocketIO, send
import json
from dao.DAOTemperatura import DAOTemperatura
from dao.DAOUsuarios import DAOUsuarios
from dao.DAOAdmin import DAOAdmin
from dao.DAOImagen import DAOImagen


app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
dbTemp = DAOTemperatura()
dbUser = DAOUsuarios()
dbAdmin = DAOAdmin()
dbImage = DAOImagen()

@app.route('/')
def index():
    session.clear()
    return render_template('login.html')

@app.route('/login_admin')
def register():
    session.clear()
    return render_template('login_admin.html')


@app.route('/validar', methods = ['POST'])
def validar():
    if request.method == 'POST' and request.form['send']:
        current_user=request.form.get('usuario')
        current_password=request.form.get('contrasena')
        if (dbUser.validar(current_user,current_password)):
            session['empresa'] = dbUser.get_empresa(current_user,current_password)
            session['user'] = current_user
            session['admin'] = False
            return redirect('/dashboard/')
        else:
            return redirect('/')

@app.route('/validar_admin', methods = ['POST'])
def validar_admin():
    if request.method == 'POST' and request.form['send']:
        current_user=request.form.get('usuario')
        current_password=request.form.get('contrasena')
        if (dbAdmin.validar(current_user,current_password)):
            session['empresa'] = dbAdmin.get_empresa(current_user,current_password)
            session['user'] = current_user
            session['admin'] = True
            return redirect('/dashboard/')
        else:
            return redirect('/')

@app.route('/dashboard/')
def dashboard():
    data = dbTemp.read_empresa(session['empresa'])
    return render_template('dashboard.html', data=data, empresa=session['empresa'])

@app.route('/sender/')
def sender():
    return render_template('sender.html')

@socketio.on('message')
def handleMessage(msg):
    messageObject = json.loads(msg)
    dbTemp.insert(messageObject)
    send(msg, broadcast=True)


if __name__ == '__main__':
    socketio.run(app, port=5000, host="0.0.0.0",debug=True)
