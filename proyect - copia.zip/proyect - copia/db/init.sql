
DROP DATABASE IF EXISTS proyecto;

CREATE DATABASE proyecto;

USE proyecto;

CREATE TABLE temperatura (
    id INT(5) AUTO_INCREMENT PRIMARY KEY,
    empresa VARCHAR(20) NOT NULL,
    fecha_hora DATETIME NOT NULL,
    temperatura REAL NOT NULL
);

CREATE TABLE imagen (
    id INT(5) AUTO_INCREMENT PRIMARY KEY,
    empresa VARCHAR(20) NOT NULL,
    fecha_hora DATETIME NOT NULL,
    imagen LONGBLOB NOT NULL
);

CREATE TABLE administradores (
    id INT(5) AUTO_INCREMENT PRIMARY KEY,
    empresa VARCHAR(20) NOT NULL,
    usuario VARCHAR(50) NOT NULL,
    contrasena VARCHAR(50) NOT NULL
);

CREATE TABLE usuarios (
    id INT(5) AUTO_INCREMENT PRIMARY KEY,
    empresa VARCHAR(20) NOT NULL,
    usuario VARCHAR(50) NOT NULL,
    contrasena VARCHAR(50) NOT NULL
);

INSERT INTO administradores (empresa, usuario, contrasena) VALUES ('Empresa1','admin', 'adminpwd');
INSERT INTO usuarios (empresa, usuario, contrasena) VALUES ('Empresa1','user1', 'user1pwd');
INSERT INTO usuarios (empresa, usuario, contrasena) VALUES ('Empresa2','user2', 'user2pwd');
INSERT INTO temperatura (empresa, fecha_hora, temperatura) VALUES ('Empresa1', NOW(), 12.1);
INSERT INTO temperatura (empresa, fecha_hora, temperatura) VALUES ('Empresa1', NOW(), 12.2);
INSERT INTO temperatura (empresa, fecha_hora, temperatura) VALUES ('Empresa1', NOW(), 12.3);
INSERT INTO temperatura (empresa, fecha_hora, temperatura) VALUES ('Empresa2', NOW(), 12.1);